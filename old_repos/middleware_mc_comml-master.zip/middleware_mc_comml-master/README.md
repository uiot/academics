<h1>![](http://i.imgur.com/lNdjvMq.png) UIoTcom <sub><sub><sup></h1></sup></sub></sub>
<br>
[![ZenHub] (https://raw.githubusercontent.com/ZenHubIO/support/master/zenhub-badge.png)] (https://zenhub.io)
[![Latest Stable Version](https://poser.pugx.org/uiot/middleware_mc_comml/v/stable.svg)](https://packagist.org/packages/uiot/middleware_mc_comml) [![Total Downloads](https://poser.pugx.org/uiot/middleware_mc_comml/downloads)](https://packagist.org/packages/uiot/middleware_mc_comml) [![Latest Unstable Version](https://poser.pugx.org/uiot/middleware_mc_comml/v/unstable.svg)](https://packagist.org/packages/uiot/middleware_mc_comml) [![License](https://poser.pugx.org/uiot/middleware_mc_comml/license.svg)](https://packagist.org/packages/uiot/middleware_mc_comml)

<b>UIoT Communication Layer</b><br>
Is the UIoT Communication Layer. More details will be provided later.

----------------------------------------------------

#### Attention! On Development. Nothing Done!
##### Obs: The Updated Branch with all New code is the "dev" branch.
