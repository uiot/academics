#include "../../../src/devicemodel/server/hserverdevice_p.h"
