#include "../../../src/general/hupnp_defs.h"
