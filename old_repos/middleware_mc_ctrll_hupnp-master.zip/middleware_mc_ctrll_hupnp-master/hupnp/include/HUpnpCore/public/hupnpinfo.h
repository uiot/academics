#include "../../../src/general/hupnpinfo.h"
