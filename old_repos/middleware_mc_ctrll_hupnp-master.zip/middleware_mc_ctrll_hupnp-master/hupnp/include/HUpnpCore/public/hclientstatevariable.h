#include "../../../src/devicemodel/client/hclientstatevariable.h"
