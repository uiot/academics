#include "../../../src/devicemodel/hdevicestatus.h"
