#include "../../../src/devicehosting/devicehost/hdevicehost_configuration.h"
