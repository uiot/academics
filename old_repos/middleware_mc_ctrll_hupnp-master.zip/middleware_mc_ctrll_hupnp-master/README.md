<h1>![](http://i.imgur.com/lNdjvMq.png) UIoTherq<sub><sub><sup></h1></sup></sub></sub>
<br>
[![ZenHub] (https://raw.githubusercontent.com/ZenHubIO/support/master/zenhub-badge.png)] (https://zenhub.io)

<b>UIoT HUPnP Layer</b></i><br>
UIoT UPnP/HERQQ Layer. More Details will be provided later.
